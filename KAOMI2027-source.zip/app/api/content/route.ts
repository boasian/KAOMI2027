import {env} from 'cloudflare:workers';
import {getDb} from '../../../db';
import {content} from '../../../db/schema';
import {and,eq} from 'drizzle-orm';
import {initial,dataSchema} from '../../content';
import {getChatGPTUser} from '../../chatgpt-auth';
export const dynamic='force-dynamic';
async function allowed(){const u=await getChatGPTUser();const email=(env as unknown as Record<string,string>).ADMIN_EMAIL;return !!u&&!!email&&u.email.toLowerCase()===email.toLowerCase();}
export async function GET(){try{const row=await getDb().select().from(content).where(eq(content.id,1)).get();return Response.json({data:row?JSON.parse(row.body):initial,revision:row?.revision||0,updatedAt:row?.updatedAt||null,canEdit:await allowed()},{headers:{'Cache-Control':'no-store'}});}catch{return Response.json({error:'안내 정보를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요.'},{status:503});}}
export async function PUT(request:Request){
 if(!await allowed())return Response.json({error:'관리자 권한이 필요합니다.'},{status:403});
 if(request.headers.get('origin')!==new URL(request.url).origin)return Response.json({error:'허용되지 않은 요청입니다.'},{status:403});
 const raw=await request.text();if(raw.length>500000)return Response.json({error:'내용이 너무 큽니다.'},{status:413});
 let input;try{input=JSON.parse(raw);}catch{return Response.json({error:'올바른 데이터가 아닙니다.'},{status:400});}
 const parsed=dataSchema.safeParse(input.data);if(!parsed.success||!Number.isInteger(input.revision)||input.revision<0)return Response.json({error:'필수 항목과 링크 주소를 확인해 주세요.'},{status:400});
 try{const db=getDb();const now=new Date().toISOString();const values={body:JSON.stringify(parsed.data),revision:input.revision+1,updatedAt:now};const changed=input.revision===0?await db.insert(content).values({id:1,...values}).onConflictDoNothing().returning():await db.update(content).set(values).where(and(eq(content.id,1),eq(content.revision,input.revision))).returning();
 if(!changed.length)return Response.json({error:'다른 창에서 변경된 내용이 있습니다. 현재 내용을 백업한 후 새로고침해 주세요.'},{status:409});return Response.json({revision:values.revision,updatedAt:now});
 }catch{return Response.json({error:'저장하지 못했습니다. 입력 내용은 유지됩니다. 다시 시도해 주세요.'},{status:503});}
}
