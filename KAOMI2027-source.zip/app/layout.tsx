import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'KAOMI iAO 2027 | 학술대회 안내',description:'2027.03.13–14 · 한국과학기술회관 B1 ST Center. 제34회 대한구강악안면임플란트학회 춘계국제종합학술대회.',openGraph:{title:'KAOMI iAO 2027 — THE PRIME MERIDIAN',description:'2027.03.13–14 · 한국과학기술회관 B1 ST Center',images:['/poster.jpg']}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ko"><body>{children}</body></html>}
