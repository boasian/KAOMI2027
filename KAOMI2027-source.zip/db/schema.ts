import {integer,sqliteTable,text} from 'drizzle-orm/sqlite-core';
export const content=sqliteTable('content',{id:integer('id').primaryKey(),body:text('body').notNull(),revision:integer('revision').notNull(),updatedAt:text('updated_at').notNull()});
